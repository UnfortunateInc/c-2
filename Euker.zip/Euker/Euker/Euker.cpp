// Euker.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <list>
using namespace std;

class Card
{
public:
	int value;
	int suit;
};

void CardVariables (int c1v, int c1s, int c2v, int c2s, int c3v, int c3s, int c4v, int c4s, int c5v, int c5s, int trump)
{
	Card c1;
	c1.value = c1v;
	c1.suit = c1s;

	Card c2;
	c2.value = c2v;
	c2.suit = c2s;

	Card c3;
	c3.value = c3v;
	c3.suit = c3s;

	Card c4;
	c4.value = c4v;
	c4.suit = c4s;

	Card c5;
	c5.value = c5v;
	c5.suit = c5s;

}
//values go up from 1-13 beginning at ace and ending at king
//suits are Clubs, Spades, Hearts, Diamonds from 1-4 respectively
//also i dont know how to play eucher so this is all going off of a guide i found online
int main()
{
	int trump = 0;

	Card c1;
	c1.value = c1v;
	c1.suit = c1s;

	Card c2;
	c2.value = c2v;
	c2.suit = c2s;

	Card c3;
	c3.value = c3v;
	c3.suit = c3s;

	Card c4;
	c4.value = c4v;
	c4.suit = c4s;

	Card c5;
	c5.value = c5v;
	c5.suit = c5s;

	list<Card> Hand;
	Hand.push_front(c1);
	Hand.push_front(c2);
	Hand.push_front(c3);
	Hand.push_front(c4);
	Hand.push_front(c5);

	int handValue = 0;
	for (Card c : Hand)
	{
		if (c.suit == trump)
		{
			if (c.value == 9 || c.value == 10)
			{
				handValue = handValue + 1;
			}
			else if (c.value == 11)
			{
				handValue = handValue + 4;
			}
			else if (c.value == 12 || c.value == 13)
			{
				handValue = handValue + 2;
			}
			else if (c.value == 1)
			{
				handValue = handValue + 3;
			}
		}

		if (!trump == c.suit)
		{
			if (c.value == 1)
			{
				handValue = handValue + 2;
			}
		}
		if (trump == 1)
		{
			if (c.suit == 2)
			{
				if (c.value == 11)
				{
					handValue = handValue + 3;				 
				}
			}
		}
		if (trump == 2)
		{
			if (c.suit == 1)
			{
				if (c.value == 11)
				{
					handValue = handValue + 3;
				}
			}
		}
		if (trump == 3)
		{
			if (c.suit == 4)
			{
				if (c.value == 11)
				{
					handValue = handValue + 3;
				}
			}
		}
		if (trump == 4)
		{
			if (c.suit == 3)
			{
				if (c.value == 11)
				{
					handValue = handValue + 3;
				}
			}
		}
	};

	std::cout << "the value of your hand is " << handValue;


	

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
